import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faChevronRight, faChevronLeft, faMinus, faPlus } from '@fortawesome/free-solid-svg-icons';
import { apiService } from './services/api-service';

interface IProductClass {
    id: number;
    name: string;
    price: number;
    discount: number;
    category: string;
    img_url: string;
}

interface ICartProps {
    value: number;
}

interface ICartState {
    value: number;
    disabled: boolean;
    productList: IProductClass[];
    error?: string;
}

export default class CartViewComponent extends React.Component<ICartProps, ICartState> {

    public props: ICartProps;
    constructor(props: ICartProps) {
        super(props);
        this.props = props;
        this.state = {
            value: 0,
            disabled: true,
            productList: [],
            error: ''
        }
        this.removeFromCart = this.removeFromCart.bind(this);
    }

    async componentDidMount() {
        let arrayValue: any = [];
        arrayValue = localStorage.getItem('cartProducts');

        // console.log('arrayValue ', arrayValue);
        if (arrayValue == null) {
            return false;
        }
        apiService.getCall('', '', null)
            .then(
                (product) => {
                    var filtered = product.filter(function (item: any) {
                        return arrayValue.indexOf(item.id) !== -1;
                    });
                    this.setState({
                        productList: filtered
                    });
                },
                (error) => {
                    this.setState({ error });
                },
            );

        console.log('cart item ', this.state.productList);
    }

    render(): JSX.Element | null {
        return (
            <React.Fragment>
                <section className="section-pagetop bg">
                    <div className="container">
                        <h2 className="title-page">Shopping cart</h2>
                    </div>
                </section>
                <section className="section-content padding-y">
                    <div className="container">
                        <div className="row">
                            <main className="col-md-9">
                                <div className="card">
                                    <table className="table table-borderless table-shopping-cart">
                                        <thead className="text-muted">
                                            <tr className="small text-uppercase">
                                                <th scope="col">Product</th>
                                                <th scope="col" style={{ width: '120' }}>Quantity</th>
                                                <th scope="col" style={{ width: '120' }}>Price</th>
                                                <th scope="col" className="text-right" style={{ width: '120' }}> </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.state.productList !== null && this.state.productList.map((items: IProductClass, index: number) => {
                                                return (
                                                    <tr key={index}>
                                                        <td>
                                                            <figure className="itemside">
                                                                <div className="aside">
                                                                    <img src={items.img_url} alt={items.name} className="img-sm" />
                                                                </div>
                                                                <figcaption className="info">
                                                                    <a href="/#" className="title text-dark">
                                                                        {items.name}</a>
                                                                    <p className="text-muted small">Category: {items.category}
                                                                    </p>
                                                                </figcaption>
                                                            </figure>
                                                        </td>
                                                        <td>
                                                            {/* <select className="form-control">
                                                                <option>1</option>
                                                                <option>2</option>
                                                                <option>3</option>
                                                                <option>4</option>
                                                            </select> */}

                                                            <div className="msc-cart-line__product-quantity">
                                                                <div className="msc-cart-line__product-quantity-label">Quantity</div>
                                                                <div className="quantity" id={"msc-cart-line__quantity_" + items.id}>
                                                                    <button className="decrement quantity__controls " id={"decrementQuantity_" + items.id}
                                                                    onClick={() => { this.decrementCounter(this) }}
                                                                    disabled={this.state.disabled}
                                                                    
                                                                    aria-hidden="true" tabIndex={-1} color="secondary">
                                                                       <FontAwesomeIcon icon={faMinus} className="fa fa-minus" />
                                                                        </button>
                                                                    <input type="number" className="quantity-input" pattern="[0-9]*" aria-live="polite" aria-label="quantity input"
                                                                        role="spinbutton" value={this.state.value} 
                                                                        onChange={() => this.handleChange}
                                                                        
                                                                        />
                                                                    <button className="increment quantity__controls "  id={"incrementQuantity_" + items.id}
                                                                    onClick={() => { this.incrementCounter(this) }}
                                                                    
                                                                    aria-hidden="true" tabIndex={-1} color="secondary">
                                                                    <FontAwesomeIcon icon={faPlus} className="fa fa-plus" />
                                                                        </button>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="price-wrap">
                                                                <var className="price">{items.price}</var>
                                                                {/* <small className="text-muted"> $315.20 each </small> */}
                                                            </div>
                                                        </td>
                                                        <td className="text-right">
                                                            {/* <a data-original-title="Save to Wishlist" title="" href="/#" className="btn btn-light" data-toggle="tooltip">
                                                                <FontAwesomeIcon icon={faHeart} className="fa fa-heart" />
                                                            </a> */}
                                                            <a href="/#" className="btn btn-light" onClick={() => this.removeFromCart(this, items.id)}>
                                                                <FontAwesomeIcon icon={faTrash} className="fa fa-trash" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                    <div className="card-body border-top">
                                        <a href="/#" className="btn btn-primary float-md-right">
                                            Make Purchase
                                            <FontAwesomeIcon icon={faChevronRight} className="fa fa-chevron-right" />
                                        </a>
                                        <a href="/#" className="btn btn-light">
                                            <FontAwesomeIcon icon={faChevronLeft} className="fa fa-chevron-left" />
                                            Continue shopping
                                        </a>
                                    </div>
                                </div>
                            </main>
                            <aside className="col-md-3">
                                <div className="card">
                                    <div className="card-body">
                                        <dl className="dlist-align">
                                            <dt>Total price:</dt>
                                            <dd className="text-right">USD 568</dd>
                                        </dl>
                                        <dl className="dlist-align">
                                            <dt>Discount:</dt>
                                            <dd className="text-right">USD 658</dd>
                                        </dl>
                                        <hr />
                                        <dl className="dlist-align">
                                            <dt>Total:</dt>
                                            <dd className="text-right  h5"><strong>$1,650</strong></dd>
                                        </dl>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </section>
            </React.Fragment>
        );
    }

    private removeFromCart(e: any, productID: number): void {
        var array = this.state.productList.filter(item => item.id !== productID);
        console.log('array ', array);
        localStorage.removeItem('cartProducts');
        localStorage.setItem('cartProducts', JSON.stringify(array));
    }

    private handleChange = (value: number) => {
        console.log('handle change ', value);
        this.setState({
            value: value
        })
    };

    incrementCounter(e: any) {
        this.setState({
            value: this.state.value + 1, disabled: false
        });
    }
    
    decrementCounter(e: any) {
        if (this.state.value <= 0) {
            return;
        };
        this.setState({
            value: this.state.value - 1
        });
        if (this.state.value - 1 <= 0) {
            this.setState({
                disabled: true
            });
        }
    }

}
