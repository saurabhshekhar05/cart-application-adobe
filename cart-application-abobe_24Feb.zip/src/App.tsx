import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import 'bootstrap/scss/bootstrap.scss';
import './App.scss';
import WrapperComponent from './wrapper';
import CartViewComponent from './cart-view';
import HeaderViewComponent from './header-view';

interface IAppProps {
    isAdded?: number;
}
interface IAppState {
    cartitems: number;
    cartProducts: any;
}

class App extends React.Component<IAppProps, IAppState> {

    public props: IAppProps;
    public state: IAppState;

    constructor(props: IAppProps) {
        super(props);
        this.props = props;
        this.state = {
            cartitems: 0, cartProducts: []
        };
        this.updateCartitem = this.updateCartitem.bind(this);
    }

    private updateCartitem(productID: number) {
        console.log("updateCartitem clicked", productID);
        let oldproduct: any = [];        
        oldproduct = localStorage.getItem('cartProducts') ? localStorage.getItem('cartProducts') : "[]";
        let arrayproduct =  JSON.parse(oldproduct);  
        
        arrayproduct.push(productID);
        localStorage.setItem('cartProducts', JSON.stringify(arrayproduct)); 
        
        // var newStateArray = this.state.cartProducts.slice();
        // newStateArray.push(productID);
        // console.log('newStateArray ', newStateArray);
        
        this.setState((prevState: IAppState) => ({
            cartitems: prevState.cartitems + 1,
            cartProducts: arrayproduct
        }));
        // this.setState({
        //     cartProducts: localStorage.getItem('cartProducts')
        // });
        // console.log('cartProducts ', this.state.cartProducts);
        console.log('cartProducts ', localStorage.getItem('cartProducts'));
        // localStorage.setItem('cartProducts', newStateArray);
    }

    public render(): JSX.Element {
        return (
            <BrowserRouter>
                <div className="App">
                    <header className="section-header">
                        <section className="header-main border-bottom">
                            <HeaderViewComponent 
                            cartProduct={Object.values(JSON.parse(localStorage.getItem('cartProducts')!)).flat().length} />
                        </section>
                    </header>
                    <Switch>
                        <Route path='/' exact={true} render={() => <WrapperComponent updateCartitem={this.updateCartitem} />} />
                        <Route path='/cart' exact={true} component={CartViewComponent} />
                    </Switch>
                </div>
            </BrowserRouter>
        );
    }
}

export default App;