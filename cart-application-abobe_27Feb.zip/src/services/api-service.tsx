import { siteConfig } from '../config/config';

export const apiService = {
    getCall,
    postCall,
    putCall,
    deleteCall,
    Login,
    logOut,
};

async function Login(data: any, methodName: string) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    };
    console.log(siteConfig.apiURL);
    const response = await fetch(siteConfig.apiURL + methodName, requestOptions);
    const user = await handleResponse(response);
    // login successful if there's a user in the response
    if (user) {
        console.log('In API success');
        // store user details and basic auth credentials in local storage
        // to keep user logged in between page refreshes
        user.authdata = window.btoa(data.username + ':' + data.password);
        localStorage.setItem('user', JSON.stringify(user));
        sessionStorage.setItem('loggedIn', 'true');
    }
    return user;
}

async function getCall(parameter: string, methodName: string, data?: any) {
    const requestOptions = {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
        body: data !== null ? JSON.stringify({ data }) : null,
    };
    const response =  parameter === '' ? await fetch(siteConfig.apiURL + methodName, requestOptions)
        : await fetch(siteConfig.apiURL + methodName + "?" + parameter + "= " + data);
    const userData = await handleResponse(response);
    return userData;
}

async function postCall(data: any, methodName: string) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    };
    const response = await fetch(siteConfig.apiURL + methodName, requestOptions);
    const userData = await handleResponse(response);
    return userData;
}

async function putCall(data: any, methodName: string) {
    const requestOptions = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data }),
    };
    const response = await fetch(siteConfig.apiURL + methodName, requestOptions);
    const userData = await handleResponse(response);
    return userData;
}

async function deleteCall(data: any, methodName: string) {
    const requestOptions = {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data }),
    };
    const response = await fetch(siteConfig.apiURL + methodName, requestOptions);
    const userData = await handleResponse(response);
    return userData;
}

function logOut() {
    // remove user from local storage to log user out
    localStorage.removeItem('user');
    sessionStorage.removeItem('loggedIn');
}

function handleResponse(response: any) {
    return response.text().then((text: string) => {
        const data = text && JSON.parse(text);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api
                logOut();
                window.location.reload(true);
            }
            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }
        return data;
    });
}
