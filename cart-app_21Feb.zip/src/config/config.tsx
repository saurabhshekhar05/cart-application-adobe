export enum siteConfig {
  siteName = "Shopping Portal",
  apiURL = "https://api.myjson.com/bins/qzuzi",
}
