import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart, faTrash, faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { apiService } from './services/api-service';

interface IProductClass {
    id: number;
    name: string;
    price: number;
    discount: number;
    category: string;
    img_url: string;
}

interface ICartProps {
    value: number;
}

interface ICartState {
    value: number;
    productList: IProductClass[];
    error?: string;
}

export default class CartViewComponent extends React.Component<ICartProps, ICartState> {

    public props: ICartProps;
    constructor(props: ICartProps) {
        super(props);
        this.props = props;
        this.state = {
            value: props.value,
            productList: [],
            error: ''
        }
    }

    async componentDidMount() {
        let arrayValue: any = [];
        arrayValue = localStorage.getItem('cartProducts');

        console.log('arrayValue ', arrayValue);

        apiService.getCall('', '', null)
            .then(
                (product) => {
                    var filtered = product.filter(function (item: any) {
                        return arrayValue.indexOf(item.id) !== -1;
                    });
                    this.setState({
                        productList: filtered
                    });
                },
                (error) => {
                    this.setState({ error });
                },
            );

        console.log('cart item ', this.state.productList);
    }

    render(): JSX.Element | null {
        return (
            <React.Fragment>
                <section className="section-pagetop bg">
                    <div className="container">
                        <h2 className="title-page">Shopping cart</h2>
                    </div>
                </section>
                <section className="section-content padding-y">
                    <div className="container">
                        <div className="row">
                            <main className="col-md-9">
                                <div className="card">
                                    <table className="table table-borderless table-shopping-cart">
                                        <thead className="text-muted">
                                            <tr className="small text-uppercase">
                                                <th scope="col">Product</th>
                                                <th scope="col" style={{ width: '120' }}>Quantity</th>
                                                <th scope="col" style={{ width: '120' }}>Price</th>
                                                <th scope="col" className="text-right" style={{ width: '120' }}> </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.state.productList !== null && this.state.productList.map((items: IProductClass, index: number) => {
                                                return (
                                                    <tr key={index}>
                                                        <td>
                                                            <figure className="itemside">
                                                                <div className="aside">
                                                                    <img src={items.img_url} alt={items.name} className="img-sm" />
                                                                </div>
                                                                <figcaption className="info">
                                                                    <a href="/#" className="title text-dark">
                                                                        {items.name}</a>
                                                                    <p className="text-muted small">Category: {items.category}
                                                                    </p>
                                                                </figcaption>
                                                            </figure>
                                                        </td>
                                                        <td>
                                                            <select className="form-control">
                                                                <option>1</option>
                                                                <option>2</option>
                                                                <option>3</option>
                                                                <option>4</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <div className="price-wrap">
                                                                <var className="price">{items.price}</var>
                                                                {/* <small className="text-muted"> $315.20 each </small> */}
                                                            </div>
                                                        </td>
                                                        <td className="text-right">
                                                            <a data-original-title="Save to Wishlist" title="" href="/#" className="btn btn-light" data-toggle="tooltip">
                                                                <FontAwesomeIcon icon={faHeart} className="fa fa-heart" />
                                                            </a>
                                                            <a href="/#" className="btn btn-light">
                                                                <FontAwesomeIcon icon={faTrash} className="fa fa-heart" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                    <div className="card-body border-top">
                                        <a href="/#" className="btn btn-primary float-md-right">
                                            Make Purchase
                                            <FontAwesomeIcon icon={faChevronRight} className="fa fa-chevron-right" />
                                        </a>
                                        <a href="/#" className="btn btn-light">
                                            <FontAwesomeIcon icon={faChevronLeft} className="fa fa-chevron-left" />
                                            Continue shopping
                                        </a>
                                    </div>
                                </div>
                            </main>
                            <aside className="col-md-3">
                                <div className="card">
                                    <div className="card-body">
                                        <dl className="dlist-align">
                                            <dt>Total price:</dt>
                                            <dd className="text-right">USD 568</dd>
                                        </dl>
                                        <dl className="dlist-align">
                                            <dt>Discount:</dt>
                                            <dd className="text-right">USD 658</dd>
                                        </dl>
                                        <hr />
                                        <dl className="dlist-align">
                                            <dt>Total:</dt>
                                            <dd className="text-right  h5"><strong>$1,650</strong></dd>
                                        </dl>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </section>
            </React.Fragment>
        );
    }
}
