import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import 'bootstrap/scss/bootstrap.scss';
import './App.scss';
import WrapperComponent from './wrapper';
import CartViewComponent from './cart-view';
import HeaderViewComponent from './header-view';

interface IAppProps {
    isAdded?: number;
}
interface IAppState {
    cartitems: number;
    cartProducts: any;
}

class App extends React.Component<IAppProps, IAppState> {

    public props: IAppProps;
    public state: IAppState;

    constructor(props: IAppProps) {
        super(props);
        this.props = props;
        this.state = {
            cartitems: 0, cartProducts: []
        };
        this.updateCartitem = this.updateCartitem.bind(this);
    }

    private updateCartitem(productID: number) {
        console.log("updateCartitem clicked", productID);
        var newStateArray = this.state.cartProducts.slice();
        newStateArray.push(productID);
        console.log('newStateArray ', newStateArray);
        this.setState((prevState: IAppState) => ({
            cartitems: prevState.cartitems + 1
            // cartProducts: newStateArray
            // cartProducts: [...prevState.cartProducts, productID]// this.state.cartProducts.concat(productID)
        }));
        this.setState({

            cartProducts: newStateArray
        });
        console.log('cartProducts ', this.state.cartProducts);
        localStorage.setItem('cartProducts', newStateArray);
    }

    public render(): JSX.Element {
        return (
            <BrowserRouter>
                <div className="App">
                    <header className="section-header">
                        <section className="header-main border-bottom">
                            <HeaderViewComponent cartProduct={this.state.cartitems} />
                        </section>
                    </header>
                    <Switch>
                        <Route path='/' exact={true} render={() => <WrapperComponent updateCartitem={this.updateCartitem} />} />
                        <Route path='/cart' exact={true} component={CartViewComponent} />
                    </Switch>
                </div>
            </BrowserRouter>
        );
    }
}

export default App;